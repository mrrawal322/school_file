// Main JavaScript file for Bright Star Academy Portal

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initializeComponents();
    initializeFormValidation();
    initializeDataTables();
    initializeTooltips();
    initializeAutoHideAlerts();
});

// Initialize Bootstrap components
function initializeComponents() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
}

// Initialize form validation
function initializeFormValidation() {
    // Bootstrap form validation
    var forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Password confirmation validation
    const passwordFields = document.querySelectorAll('input[type="password"]');
    passwordFields.forEach(field => {
        if (field.name === 'confirm_password') {
            field.addEventListener('input', function() {
                const passwordField = document.querySelector('input[name="new_password"], input[name="password"]');
                if (passwordField && this.value !== passwordField.value) {
                    this.setCustomValidity('Passwords do not match');
                } else {
                    this.setCustomValidity('');
                }
            });
        }
    });

    // Email validation enhancement
    const emailFields = document.querySelectorAll('input[type="email"]');
    emailFields.forEach(field => {
        field.addEventListener('blur', function() {
            if (this.value && !isValidEmail(this.value)) {
                this.setCustomValidity('Please enter a valid email address');
            } else {
                this.setCustomValidity('');
            }
        });
    });
}

// Initialize DataTables for better table management
function initializeDataTables() {
    const tables = document.querySelectorAll('.table');
    tables.forEach(table => {
        if (table.rows.length > 10) {
            // Add simple pagination for large tables
            addTablePagination(table);
        }
    });
}

// Initialize tooltips
function initializeTooltips() {
    const tooltips = document.querySelectorAll('[title]');
    tooltips.forEach(element => {
        element.setAttribute('data-bs-toggle', 'tooltip');
        new bootstrap.Tooltip(element);
    });
}

// Auto-hide alerts after 5 seconds
function initializeAutoHideAlerts() {
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
}

// Utility Functions

// Email validation
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Add table pagination
function addTablePagination(table) {
    const rowsPerPage = 10;
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    if (rows.length <= rowsPerPage) return;
    
    let currentPage = 1;
    const totalPages = Math.ceil(rows.length / rowsPerPage);
    
    // Create pagination container
    const paginationContainer = document.createElement('div');
    paginationContainer.className = 'pagination-container mt-3';
    table.parentNode.appendChild(paginationContainer);
    
    function showPage(page) {
        rows.forEach((row, index) => {
            const start = (page - 1) * rowsPerPage;
            const end = start + rowsPerPage;
            row.style.display = (index >= start && index < end) ? '' : 'none';
        });
        updatePaginationButtons();
    }
    
    function updatePaginationButtons() {
        paginationContainer.innerHTML = `
            <nav aria-label="Table pagination">
                <ul class="pagination justify-content-center">
                    <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                    ${generatePageNumbers()}
                    <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                </ul>
            </nav>
        `;
        
        // Add click events
        paginationContainer.querySelectorAll('.page-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = parseInt(e.target.dataset.page);
                if (page && page !== currentPage && page >= 1 && page <= totalPages) {
                    currentPage = page;
                    showPage(currentPage);
                }
            });
        });
    }
    
    function generatePageNumbers() {
        let pages = '';
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                pages += `
                    <li class="page-item ${i === currentPage ? 'active' : ''}">
                        <a class="page-link" href="#" data-page="${i}">${i}</a>
                    </li>
                `;
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                pages += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        return pages;
    }
    
    // Initialize
    showPage(1);
}

// Form submission with loading state
function submitFormWithLoading(form, buttonText = 'Processing...') {
    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    
    submitButton.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>${buttonText}`;
    submitButton.disabled = true;
    
    // Re-enable after 5 seconds as fallback
    setTimeout(() => {
        submitButton.innerHTML = originalText;
        submitButton.disabled = false;
    }, 5000);
}

// Show confirmation dialog
function showConfirmDialog(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// Show loading overlay
function showLoadingOverlay(message = 'Loading...') {
    const overlay = document.createElement('div');
    overlay.id = 'loadingOverlay';
    overlay.className = 'position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    overlay.style.zIndex = '9999';
    overlay.innerHTML = `
        <div class="bg-white p-4 rounded text-center">
            <div class="spinner-border text-primary mb-3"></div>
            <div>${message}</div>
        </div>
    `;
    document.body.appendChild(overlay);
}

// Hide loading overlay
function hideLoadingOverlay() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.remove();
    }
}

// Format file size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Copy text to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showToast('Copied to clipboard!', 'success');
    }).catch(() => {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        showToast('Copied to clipboard!', 'success');
    });
}

// Show toast notification
function showToast(message, type = 'info') {
    const toastContainer = getOrCreateToastContainer();
    const toastId = 'toast-' + Date.now();
    
    const toast = document.createElement('div');
    toast.id = toastId;
    toast.className = `toast align-items-center text-white bg-${type === 'error' ? 'danger' : type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    toastContainer.appendChild(toast);
    
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    // Remove toast element after it's hidden
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}

// Get or create toast container
function getOrCreateToastContainer() {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container position-fixed top-0 end-0 p-3';
        document.body.appendChild(container);
    }
    return container;
}

// Debounce function for search inputs
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Search functionality for tables
function addTableSearch(tableId, searchInputId) {
    const table = document.getElementById(tableId);
    const searchInput = document.getElementById(searchInputId);
    
    if (!table || !searchInput) return;
    
    const searchFunction = debounce(function(searchTerm) {
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm.toLowerCase()) ? '' : 'none';
        });
    }, 300);
    
    searchInput.addEventListener('input', (e) => {
        searchFunction(e.target.value);
    });
}

// Auto-save form data to localStorage
function enableFormAutoSave(formId, key) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    // Load saved data
    const savedData = localStorage.getItem(key);
    if (savedData) {
        const data = JSON.parse(savedData);
        Object.keys(data).forEach(fieldName => {
            const field = form.querySelector(`[name="${fieldName}"]`);
            if (field) {
                field.value = data[fieldName];
            }
        });
    }
    
    // Save data on input
    form.addEventListener('input', debounce(() => {
        const formData = new FormData(form);
        const data = {};
        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }
        localStorage.setItem(key, JSON.stringify(data));
    }, 1000));
    
    // Clear saved data on successful submit
    form.addEventListener('submit', () => {
        localStorage.removeItem(key);
    });
}

// Form validation helpers
const validators = {
    required: (value) => value.trim() !== '',
    email: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
    minLength: (value, length) => value.length >= length,
    maxLength: (value, length) => value.length <= length,
    number: (value) => !isNaN(value) && !isNaN(parseFloat(value)),
    positive: (value) => parseFloat(value) > 0
};

// Custom form validation
function validateForm(formId, rules) {
    const form = document.getElementById(formId);
    if (!form) return false;
    
    let isValid = true;
    const errors = {};
    
    Object.keys(rules).forEach(fieldName => {
        const field = form.querySelector(`[name="${fieldName}"]`);
        if (!field) return;
        
        const fieldRules = rules[fieldName];
        const value = field.value;
        
        fieldRules.forEach(rule => {
            if (typeof rule === 'string') {
                if (!validators[rule](value)) {
                    isValid = false;
                    errors[fieldName] = errors[fieldName] || [];
                    errors[fieldName].push(rule);
                }
            } else if (typeof rule === 'object') {
                const { validator, param, message } = rule;
                if (!validators[validator](value, param)) {
                    isValid = false;
                    errors[fieldName] = errors[fieldName] || [];
                    errors[fieldName].push(message || validator);
                }
            }
        });
    });
    
    // Display errors
    displayFormErrors(form, errors);
    
    return isValid;
}

// Display form validation errors
function displayFormErrors(form, errors) {
    // Clear previous errors
    form.querySelectorAll('.invalid-feedback').forEach(el => el.remove());
    form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
    
    // Display new errors
    Object.keys(errors).forEach(fieldName => {
        const field = form.querySelector(`[name="${fieldName}"]`);
        if (field) {
            field.classList.add('is-invalid');
            const errorDiv = document.createElement('div');
            errorDiv.className = 'invalid-feedback';
            errorDiv.textContent = errors[fieldName].join(', ');
            field.parentNode.appendChild(errorDiv);
        }
    });
}

// Global error handler
window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
    // Only show user-friendly message in production
    if (window.location.hostname !== 'localhost') {
        showToast('An unexpected error occurred. Please refresh the page.', 'error');
    }
});

// Notification Popup Functions
function showNotificationPopup() {
    const popup = document.getElementById('notificationPopup');
    if (popup) {
        popup.classList.add('show');
        // Auto hide after 10 seconds
        setTimeout(() => {
            hideNotificationPopup();
        }, 10000);
    }
}

function hideNotificationPopup() {
    const popup = document.getElementById('notificationPopup');
    if (popup) {
        popup.classList.remove('show');
    }
}

// Question Form Session Storage for Chapter Persistence
function saveChapterInfo() {
    const subject = document.querySelector('[name="subject"]');
    const classLevel = document.querySelector('[name="class_level"]');
    const chapterName = document.querySelector('[name="chapter_name"]');
    const chapterNumber = document.querySelector('[name="chapter_number"]');
    
    if (subject && classLevel && chapterName && chapterNumber) {
        const chapterInfo = {
            subject: subject.value,
            class_level: classLevel.value,
            chapter_name: chapterName.value,
            chapter_number: chapterNumber.value
        };
        
        sessionStorage.setItem('questionChapterInfo', JSON.stringify(chapterInfo));
    }
}

function loadChapterInfo() {
    const saved = sessionStorage.getItem('questionChapterInfo');
    if (saved) {
        const chapterInfo = JSON.parse(saved);
        
        const subject = document.querySelector('[name="subject"]');
        const classLevel = document.querySelector('[name="class_level"]');
        const chapterName = document.querySelector('[name="chapter_name"]');
        const chapterNumber = document.querySelector('[name="chapter_number"]');
        
        if (subject && chapterInfo.subject) subject.value = chapterInfo.subject;
        if (classLevel && chapterInfo.class_level) classLevel.value = chapterInfo.class_level;
        if (chapterName && chapterInfo.chapter_name) chapterName.value = chapterInfo.chapter_name;
        if (chapterNumber && chapterInfo.chapter_number) chapterNumber.value = chapterInfo.chapter_number;
    }
}

function clearChapterInfo() {
    sessionStorage.removeItem('questionChapterInfo');
}

// Auto show notification on page load for logged in users
document.addEventListener('DOMContentLoaded', function() {
    // Show notification popup after 3 seconds for authenticated users
    const notificationBell = document.getElementById('notificationBell');
    if (notificationBell) {
        setTimeout(() => {
            showNotificationPopup();
        }, 3000);
    }
    
    // Load saved chapter info for question forms
    if (document.querySelector('form[data-form-type="question"]')) {
        loadChapterInfo();
    }
});

// Export functions for use in other scripts
window.AcademyPortal = {
    showToast,
    showConfirmDialog,
    showLoadingOverlay,
    hideLoadingOverlay,
    copyToClipboard,
    formatFileSize,
    debounce,
    validateForm,
    enableFormAutoSave,
    addTableSearch,
    submitFormWithLoading,
    showNotificationPopup,
    hideNotificationPopup,
    saveChapterInfo,
    loadChapterInfo,
    clearChapterInfo
};
